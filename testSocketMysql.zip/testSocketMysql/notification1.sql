/*
SQLyog Community Edition- MySQL GUI v8.02 
MySQL - 5.7.17-log : Database - applicantbank
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`applicantbank` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `applicantbank`;

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `messages` varchar(45) DEFAULT NULL,
  `userID` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT 'X',
  `timestamp` timestamp(6) NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `notification` */

insert  into `notification`(`mid`,`messages`,`userID`,`status`,`timestamp`) values (4,'LC-XXXX has been Opened','jacobs','X','2018-02-05 15:09:00.673924'),(8,'test','jacobs','x','2018-02-06 12:59:55.491428'),(9,'LC-XXXX has been Approved','jacobs','X','2018-02-06 13:00:20.297388'),(10,'asdf','jacobs','X','2018-02-06 13:00:20.338896');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
