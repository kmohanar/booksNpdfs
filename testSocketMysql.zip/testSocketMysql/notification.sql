/*
SQLyog Community Edition- MySQL GUI v8.02 
MySQL - 5.7.17-log : Database - beneficiarybank
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`beneficiarybank` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `beneficiarybank`;

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `messages` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `timestamp` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `applicant` varchar(45) DEFAULT NULL,
  `applicantbank` tinyint(1) DEFAULT NULL,
  `beneficiary` varchar(45) DEFAULT NULL,
  `beneficiarybank` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `notification` */

insert  into `notification`(`mid`,`messages`,`status`,`timestamp`,`applicant`,`applicantbank`,`beneficiary`,`beneficiarybank`) values (1,'lcreqw','req','2018-02-06 10:07:57.615151',NULL,NULL,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
