import { Hero } from './hero';

// export const HEROS: Hero[] = [
export const HEROES: Hero[] = [
    { id: 10, name: 'Ironman' },
    { id: 11, name: 'Superman' },
    { id: 12, name: 'Heman' },
    { id: 13, name: 'Batman' },
    { id: 14, name: 'Shaktiman' },
    { id: 15, name: 'Wonder Woman' },
    { id: 16, name: 'Thor' }

];

