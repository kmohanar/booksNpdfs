import { Component, OnInit } from '@angular/core';
import { Hero } from '../hero';
import { HEROES } from '../mock-heros';
@Component({
  selector: 'app-heros',
  templateUrl: './heros.component.html',
  styleUrls: ['./heros.component.css']
})
export class HerosComponent implements OnInit {
  // hero = 'Windstorm';
  // hero: Hero = {
  //   id: 1,
  //   name: 'Windstrom'

  // };
  //  heroes: HEROES ;>>>>>>>>>>>>>wrong assignment
  heroes = HEROES;    // getting the object here
  // selectedHero = Hero; >>>>>>>>>>>>>>>wrong assignment
  selectedHero: Hero;     // getting the class here(compare with line number 17)


  constructor() { }

  ngOnInit() {
  }
  onSelect(hero: Hero): void {
    this.selectedHero = hero;

  }

}
